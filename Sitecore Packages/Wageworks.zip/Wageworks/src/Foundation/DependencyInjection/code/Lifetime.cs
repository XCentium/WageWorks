﻿namespace Vista.Foundation.DependencyInjection
{
    public enum Lifetime
    {
        Transient,
        Singleton
    }
}