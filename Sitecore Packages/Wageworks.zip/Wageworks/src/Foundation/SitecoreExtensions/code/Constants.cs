﻿namespace Vista.Foundation.SitecoreExtensions
{
  public struct Constants
  {
    public struct DynamicPlaceholdersLayoutParameters
    {
      public static string UseStaticPlaceholderNames => "UseStaticPlaceholderNames";
    }

      public struct PromoLayoutParameters
      {
          public static string CssVariant => "CSS Variants";
          public static string CssFieldName => "CSS Class Name";
      }
    }
}