﻿using Sitecore.Data.Items;

namespace Vista.Foundation.SitecoreExtensions.Models
{
    public interface IFormModel
    {
        Item Item { get; set; }
    }
}