﻿namespace Vista.Feature.News
{
    public struct Constants
    {
        public static readonly string AlertIdFormatString = "alert-{0}";
        public static readonly string TopicQueryString = "topic";
    }
}